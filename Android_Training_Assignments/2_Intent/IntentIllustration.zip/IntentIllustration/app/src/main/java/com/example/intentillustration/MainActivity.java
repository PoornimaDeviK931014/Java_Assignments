package com.example.intentillustration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onJumpToSecondActivity(View view) {
        Intent i = new Intent(getApplicationContext(), SecondActivity.class);
        startActivity(i);
    }

    public void onExplicit(View view) {
        EditText e = findViewById(R.id.web);

        String url=e.getText().toString();
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);

// Try to invoke the intent.
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException ex) {
            // Define what your app should do if no activity can handle the intent.
        }

    }
}