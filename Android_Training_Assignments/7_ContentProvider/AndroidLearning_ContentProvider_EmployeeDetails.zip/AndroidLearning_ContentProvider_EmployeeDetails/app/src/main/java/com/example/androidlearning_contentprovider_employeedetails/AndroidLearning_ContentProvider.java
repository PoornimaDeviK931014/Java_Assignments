package com.example.androidlearning_contentprovider_employeedetails;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.HashMap;
import java.util.Objects;

public class AndroidLearning_ContentProvider extends ContentProvider {

    // creating object of database
    // to perform query
    private SQLiteDatabase db;

    // declaring name of the database
    static final String DATABASE_NAME = "Training_CP_DB";
    static final int DATABASE_VERSION = 1;

    // declaring table name of the database
    static final String TABLE_NAME = "EmployeeDetails";
    // Emp ID , Designation,  Name, Salary

    // important and mandatory for Content provider
    static final String PROVIDER_NAME = "com.example.androidLearning_EmployeeDetails.provider";

    static final String URL = "content://" + PROVIDER_NAME + "/EmployeeDetails";

    static final String id = "emp_id";
    static final String name = "emp_name";

    static final String desg = "emp_designation";
    static final String sal = "emp_salary";

    // parsing the content URI
    static final Uri CONTENT_URI = Uri.parse(URL);
    static final int uriCode = 1;
    static UriMatcher uriMatcher;

    private static HashMap<String, String> values;
    static final String CREATE_DB_TABLE = " CREATE TABLE " + TABLE_NAME
            + " (emp_id INTEGER PRIMARY KEY , "
            + " emp_name TEXT NOT NULL,"
            + " emp_designation TEXT NOT NULL,"
            + " emp_salary INTEGER NOT NULL);";
    public static class DBHelper extends SQLiteOpenHelper
    {

        public DBHelper(@Nullable Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL(CREATE_DB_TABLE);

        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            // Do Toast
            // Ideally, we need to copy the old data from old DB and then port to new DB
//            Toast.makeText("Updated Version",Toast.LENGTH_LONG).show();
        }
    }

    static {

        // to match the content URI
        // every time user access table under content provider
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

        // to access whole table
        uriMatcher.addURI(PROVIDER_NAME, "employees", uriCode);

        // to access a particular row
        // of the table
        //uriMatcher.addURI(PROVIDER_NAME, "users/*", uriCode);
    }

    @Override
    public boolean onCreate() {

        Context context = getContext();
        DBHelper dbHelper = new DBHelper(context);
        db = dbHelper.getWritableDatabase();
        if (db != null) {
            return true;
        }
        return false;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] strings, @Nullable String s, @Nullable String[] strings1, @Nullable String s1) {

        Cursor cursor = db.query(TABLE_NAME, strings, s, strings1, null,
                null, s1);
        return cursor;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {

        switch (uriMatcher.match(uri)) {
            case uriCode:
                return "com.example.androidLearning_EmployeeDetails.provider/employees";
            default:
                throw new IllegalArgumentException("Unsupported URI: " + uri);
        }
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        long rowID = db.insert(TABLE_NAME, "", contentValues);
        if (rowID > 0) {
            Uri _uri = ContentUris.withAppendedId(CONTENT_URI, rowID);
            Objects.requireNonNull(getContext()).getContentResolver().notifyChange(_uri, null);
            return _uri;
        }
        throw new SQLiteException("Failed to add a record into " + uri);
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String s, @Nullable String[] strings) {

        int count = db.delete(TABLE_NAME, s, strings);
        return count;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String s, @Nullable String[] strings) {
        throw new UnsupportedOperationException("Not yet implemented");
//        return 0;
    }
}
