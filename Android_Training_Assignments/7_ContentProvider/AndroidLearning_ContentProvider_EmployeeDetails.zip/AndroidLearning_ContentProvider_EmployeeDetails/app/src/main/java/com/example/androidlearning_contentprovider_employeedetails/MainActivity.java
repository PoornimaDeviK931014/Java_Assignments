package com.example.androidlearning_contentprovider_employeedetails;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickInsert(View view) {

        EditText id = findViewById(R.id.empID);
        EditText name = findViewById(R.id.empName);
        EditText desg = findViewById(R.id.designation);
        EditText sal = findViewById(R.id.salary);

        // class to add values in the database
        ContentValues values = new ContentValues();

        // fetching text from user
        if(!id.getText().toString().isEmpty()) {
            values.put(AndroidLearning_ContentProvider.id, Integer.parseInt(id.getText().toString()));
        }
        else {
            Toast.makeText(this, "Please insert Employee ID", Toast.LENGTH_LONG).show();
        }
        if(!name.getText().toString().isEmpty()) {
            values.put(AndroidLearning_ContentProvider.name, name.getText().toString());
        }
        else {
            Toast.makeText(this, "Please insert Employee Name", Toast.LENGTH_LONG).show();
        }

        if(!desg.getText().toString().isEmpty()) {
            values.put(AndroidLearning_ContentProvider.desg, desg.getText().toString());
        }
        else {
            Toast.makeText(this, "Please insert Employee designation", Toast.LENGTH_LONG).show();
        }

        if(!sal.getText().toString().isEmpty()) {
            values.put(AndroidLearning_ContentProvider.sal, Integer.parseInt(sal.getText().toString()));
        }
        else {
            Toast.makeText(this, "Please insert Employee Salary", Toast.LENGTH_LONG).show();
        }

        // inserting into database through content URI
        getContentResolver().insert(AndroidLearning_ContentProvider.CONTENT_URI, values);

        // displaying a toast message
        Toast.makeText(this, "New Record Inserted", Toast.LENGTH_LONG).show();

        id.setText("");
        name.setText("");
        desg.setText("");
        sal.setText("");
    }
    @SuppressLint("Range")
    public void onClickLoad(View view) {
        // inserting complete table details in this text field
        TextView resultView= (TextView) findViewById(R.id.dataLoad);

        // creating a cursor object of the
        // content URI
        Cursor cursor = getContentResolver().query(AndroidLearning_ContentProvider.CONTENT_URI,
                null, null, null, null);

        // iteration of the cursor
        // to print whole table
        assert cursor != null;
        if(cursor.moveToFirst()) {
            StringBuilder strBuild=new StringBuilder();
            while (!cursor.isAfterLast()) {
                strBuild.append("\n").
                        append(cursor.getString(cursor.getColumnIndex(AndroidLearning_ContentProvider.id))).
                        append("   - ").append(cursor.getString((cursor.getColumnIndex(AndroidLearning_ContentProvider.name))))
                        .append("    - ").append(cursor.getString((cursor.getColumnIndex(AndroidLearning_ContentProvider.desg))))
                        .append("    - ").append(cursor.getString((cursor.getColumnIndex(AndroidLearning_ContentProvider.sal))));
                cursor.moveToNext();
            }
            resultView.setText(strBuild);
        }
        else {
            resultView.setText("No Records Found");
        }
    }
}